<?php 

 $s_name = $_POST['sname'];
 $s_Address = $_POST['saddress'];
 $s_class = $_POST['class'];
 $s_sphone = $_POST['sphone'];

 $conn = mysqli_connect("localhost","root","","crud");

 $sql = "INSERT INTO student(sname,saddress,sclass ,sphone) VALUES('$s_name','$s_Address','$s_class','$s_sphone')";

 $result = mysqli_query($conn,$sql) or die("query unsuccessful.");

  header("Location: http://localhost/crud/index.php");

 mysqli_close($conn);


 ?>