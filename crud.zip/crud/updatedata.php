<?php 

 $s_id = $_POST['sid'];
 $s_name = $_POST['sname'];
 $s_Address = $_POST['saddress'];
 $s_class = $_POST['sclass'];
 $s_sphone = $_POST['sphone'];

 $conn = mysqli_connect("localhost","root","","crud");

 $sql = "UPDATE student SET sname = '{$s_name}',saddress = '{$s_Address}',sclass = '{$s_class}',sphone = '{$s_sphone}' where sid = {$s_id}";

 $result = mysqli_query($conn,$sql) or die("query unsuccessful.");

  header("Location: http://localhost/crud/index.php");

 mysqli_close($conn);


 ?>